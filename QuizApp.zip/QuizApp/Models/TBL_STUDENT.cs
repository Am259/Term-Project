namespace quizApp.Models
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public partial class TBL_STUDENT
{
    public TBL_STUDENT()
    {
        this.TBL_SETEXAM = new HashSet<TBL_SETEXAM>();
    }

    public int S_ID { get; set; }

    [Display(Name = "Student Name")]
    [Required(ErrorMessage = "Please enter the student name.")]
    public string S_NAME { get; set; }

    [Display(Name = "Password")]
    [Required(ErrorMessage = "Please enter the password.")]
    public string S_PASSWORD { get; set; }
    internal HashSet<TBL_SETEXAM> TBL_SETEXAM { get; }
}

internal class TBL_SETEXAM
{
}
}