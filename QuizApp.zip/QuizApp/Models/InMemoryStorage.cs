namespace quizApp.Models
{
    using System.ComponentModel.DataAnnotations;
public static class InMemoryStorage
{
    public static List<TBL_Category> Categories { get; set; } = new List<TBL_Category>();
    public static List<TBL_QUESTIONS> Questions { get; set; } = new List<TBL_QUESTIONS>();
}
}