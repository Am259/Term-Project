namespace quizApp.Models
{
    using System.ComponentModel.DataAnnotations;

    public partial class TBL_ADMIN
    {
        public int AD_ID { get; set; }

        [Display(Name = "Admin Name")]
        [Required(ErrorMessage = "*")]
        public required string AD_NAME { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "*")]
        public required string AD_PASSWORD { get; set; }
    }
}
