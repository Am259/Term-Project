namespace quizApp.Models
{
    using System.ComponentModel.DataAnnotations;

    public partial class TBL_Category
    {
         public int cat_id { get; set; }

        [Display(Name = "Subject")]
        [Required(ErrorMessage = "Category name is required.")]
        public required string cat_name { get; set; }

       
        public int cat_fk_adid { get; set; }
        public virtual required TBL_ADMIN TBL_ADMIN { get; set; }
    }
    
    }