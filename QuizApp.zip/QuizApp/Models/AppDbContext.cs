using quizApp.Models;

public class AppDbContext : DbContext
{
    internal new readonly object tbl_categroy;
    internal object TBL_QUESTIONS;

    public ISet<TBL_Category> Categories { get; set; }
    public ISet<TBL_QUESTIONS> Questions { get; set; }
    public ISet<TBL_ADMIN> Admins { get; set; }
    public ISet<TBL_STUDENT> Students { get; set; }
    // Add other DbSet properties for your models

    public AppDbContext(DbContextOptions<AppDbContext> options)
       
    {
    }

    public AppDbContext()
    {
    }

    public class DbContextOptions<T>
    {
    }

    internal void SaveChanges()
    {
        throw new NotImplementedException();
    }

    // Add configuration or other DbContext-related code as needed
}

public class DbContext
{
    internal static readonly object? tbl_categroy;
}