namespace quizApp.Models
{
    using System.ComponentModel.DataAnnotations;

    public partial class TBL_QUESTIONS
    {
        

        public int QuestionId { get; set; }

        [Display(Name = "Question Text")]
        [Required(ErrorMessage = "Please enter the question text.")]
        public required string QuestionText { get; set; }

        [Display(Name = "Option A")]
        [Required(ErrorMessage = "Please enter option A.")]
        public required string OptionA { get; set; }

        [Display(Name = "Option B")]
        [Required(ErrorMessage = "Please enter option B.")]
        public required string OptionB { get; set; }

        [Display(Name = "Option C")]
        [Required(ErrorMessage = "Please enter option C.")]
        public required string OptionC { get; set; }

        [Display(Name = "Option D")]
        [Required(ErrorMessage = "Please enter option D.")]
        public required string OptionD { get; set; }

        [Display(Name = "Correct Option")]
        [Required(ErrorMessage = "Please enter the correct option.")]
        public required string CorrectOption { get; set; }

       [Display(Name = "Select Category")]
        [Required(ErrorMessage = "Please Select Category.")]
        public required string Selectcategory { get; set; }

       
    }
}
