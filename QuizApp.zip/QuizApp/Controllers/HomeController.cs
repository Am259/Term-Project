﻿using System.Collections;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using QuizApp.Models;


namespace QuizApp.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private IEnumerable categories;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult tlogin()
    {
        
        return View();
    }
        public IActionResult slogin()
    {
        return View();
    }
     public IActionResult Dashboard()
    {
        return View();
    }
    [HttpGet]
    public IActionResult Addcategory()
    {
        var categories = new List<SelectListItem>
        {
         new SelectListItem { Value = "1", Text = "Category 1" },
         new SelectListItem { Value ="2", Text = "Category 2" },
        };
             ViewBag.CatList = new SelectList (categories,"Value", "Text");
        return View();
    }

    private dynamic GetCategories()
    {
        throw new NotImplementedException();
    }

    public IActionResult AddQuestion()
    {

        return View();
    }
    public IActionResult Questions()
    {
        return View();
    }
    public IActionResult WebCategoryQuestions()
    {
        return View();
    }
    public IActionResult OOPCategoryQuestions()
    {
        return View();
    }

   public IActionResult Dashboard2()
    {
        return View();
    }
    public IActionResult Index()
    {
        return View();
    }



    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
    
}
