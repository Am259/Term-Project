INSERT INTO tbl_questions (q_text, opa, opb, opc, opd, cop)
VALUES
 ('What does HTML stand for?', 'Hypertext', 'HTML', 'CSS', 'Script', 'HTML'),

    ('Which protocol is used for secure communication over the web?', 'FTP', 'HTTP', 'HTTPS', 'TCP', 'HTTPS'),

    ('What is the purpose of CSS in web development?', 'Style', 'Cascading', 'Design', 'Common', 'Cascading'),

    ('Which is a client-side scripting language?', 'PHP', 'Python', 'JS', 'Ruby', 'JS'),

    ('What is the role of DNS in web technology?', 'Network', 'Domain', 'Naming', 'Data', 'Domain'),

    ('Which is a markup language for creating structured documents?', 'XML', 'JSON', 'YAML', 'HTML', 'XML'),

    ('What does AJAX stand for?', 'Asynchronous JS', 'Advanced JS', 'Asynchronous JSON', 'Advanced JSON', 'Asynchronous JS'),

    ('Which HTTP method is used for submitting form data?', 'GET', 'POST', 'PUT', 'DEL', 'POST'),

    ('What is the purpose of a cookie in web development?', 'Store data', 'Manage session', 'Math', 'Graphics', 'Manage session'),

  ('What is encapsulation?', 'Data hiding', 'Class', 'Inheritance', 'Polymorphism', 'Data hiding'),

    ('What is a class in OOP?', 'Template', 'Object', 'Method', 'Variable', 'Template'),

    ('What is inheritance?', 'Methods', 'New class', 'Access members', 'Hide details', 'New class'),

    ('What is an object?', 'Function', 'Instance', 'Loop', 'Variable', 'Instance'),

    ('Encapsulation used for?', 'Code organization', 'Data hiding', 'Inheritance', 'Polymorphism', 'Data hiding'),

    ('Purpose of "super" keyword?', 'Reference superclass', 'Call static method', 'Create new object', 'Define constant', 'Reference superclass'),

    ('Allows a class with same method names?', 'Inheritance', 'Polymorphism', 'Encapsulation', 'Abstraction', 'Polymorphism'),

    ('What is an OOP constructor?', 'Return value', 'No parameters', 'Initialize object', 'Destroy object', 'Initialize object');